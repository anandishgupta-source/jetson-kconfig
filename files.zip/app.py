"""jetson-kconfig — Interactive Jetson kernel module configurator."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import List, Set

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.reactive import reactive
from textual.screen import Screen
from textual.widgets import (
    Button,
    Checkbox,
    Footer,
    Header,
    Label,
    Log,
    Markdown,
    Static,
)

from .detect import JetsonBoard, detect_board
from .features import FEATURES, Feature
from .builder import build_modules


# ─────────────────────────────────────────────────────────────────────────────
# Board info panel
# ─────────────────────────────────────────────────────────────────────────────

class BoardPanel(Static):
    """Top bar showing detected board info."""

    def __init__(self, board: JetsonBoard | None):
        self.board = board
        super().__init__()

    def render(self) -> str:
        if self.board is None:
            return (
                "[bold yellow]⚠  Board not detected[/]\n"
                "[dim]Running in demo mode — no build will be executed[/]"
            )
        return (
            f"[bold green]✔  {self.board.model}[/]\n"
            f"[dim]SoC:[/] {self.board.soc}   "
            f"[dim]L4T:[/] {self.board.l4t_version}   "
            f"[dim]defconfig:[/] {self.board.defconfig}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Feature row
# ─────────────────────────────────────────────────────────────────────────────

class FeatureRow(Horizontal):
    """A single feature checkbox row."""

    def __init__(self, feature: Feature, checked: bool = False):
        self.feature = feature
        self._checked = checked
        super().__init__(id=f"row-{feature.id}", classes="feature-row")

    def compose(self) -> ComposeResult:
        yield Checkbox(
            self.feature.name,
            value=self._checked,
            id=f"chk-{self.feature.id}",
        )
        yield Label(
            self.feature.description,
            classes="feature-desc",
        )

    @property
    def is_checked(self) -> bool:
        return self.query_one(Checkbox).value  # type: ignore


# ─────────────────────────────────────────────────────────────────────────────
# Build log screen
# ─────────────────────────────────────────────────────────────────────────────

class BuildScreen(Screen):
    """Full-screen build log."""

    BINDINGS = [Binding("q", "app.pop_screen", "Back")]

    def __init__(self, board: JetsonBoard | None, selected: List[Feature]):
        self.board = board
        self.selected = selected
        super().__init__()

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Log(id="build-log", highlight=True)
        yield Footer()

    def on_mount(self) -> None:
        log = self.query_one(Log)
        self.run_worker(self._run_build(log), exclusive=True)

    async def _run_build(self, log: Log) -> None:
        log.write_line("[bold cyan]jetson-kconfig build started[/]")
        log.write_line("")

        if self.board is None:
            log.write_line("[yellow]⚠  No board detected — dry run only[/]")

        for feature in self.selected:
            log.write_line(f"[bold]▶ Enabling: {feature.name}[/]")
            for cfg in feature.configs:
                log.write_line(f"  [dim]{cfg}[/]")

        log.write_line("")

        if self.board:
            async for line in build_modules(self.board, self.selected):
                log.write_line(line)
        else:
            log.write_line("[yellow]Dry run complete. Connect a Jetson to build.[/]")

        log.write_line("")
        log.write_line("[bold green]✔  Done. Press Q to go back.[/]")


# ─────────────────────────────────────────────────────────────────────────────
# Summary screen
# ─────────────────────────────────────────────────────────────────────────────

class SummaryScreen(Screen):
    """Show what will be built and ask for confirmation."""

    BINDINGS = [
        Binding("b", "build", "Build"),
        Binding("escape", "app.pop_screen", "Back"),
    ]

    def __init__(self, board: JetsonBoard | None, selected: List[Feature]):
        self.board = board
        self.selected = selected
        super().__init__()

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        lines = ["# Build Summary\n"]

        if self.board:
            lines.append(f"**Board:** {self.board.model}  ")
            lines.append(f"**L4T:** {self.board.l4t_version}  ")
            lines.append(f"**defconfig:** {self.board.defconfig}\n")
        else:
            lines.append("**Board:** Not detected (dry run)\n")

        lines.append("## Features to enable\n")
        for f in self.selected:
            lines.append(f"- **{f.name}** — {f.description}")
            if f.packages:
                lines.append(f"  - Userspace packages: `{', '.join(f.packages)}`")
            if f.notes:
                lines.append(f"  - Note: {f.notes}")

        lines.append("\n---\n")
        lines.append("Press **B** to start the build or **Esc** to go back.")

        yield ScrollableContainer(Markdown("\n".join(lines)))
        yield Footer()

    def action_build(self) -> None:
        self.app.push_screen(BuildScreen(self.board, self.selected))


# ─────────────────────────────────────────────────────────────────────────────
# Main screen
# ─────────────────────────────────────────────────────────────────────────────

class MainScreen(Screen):
    BINDINGS = [
        Binding("q", "app.quit", "Quit"),
        Binding("a", "select_all", "All"),
        Binding("n", "select_none", "None"),
        Binding("enter", "review", "Review & Build"),
    ]

    def __init__(self, board: JetsonBoard | None):
        self.board = board
        super().__init__()

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Vertical():
            yield BoardPanel(self.board)
            yield Static("[bold]Select kernel features to enable:[/]\n", classes="section-label")
            with ScrollableContainer(id="feature-list"):
                for feature in FEATURES:
                    yield FeatureRow(feature)
            with Horizontal(id="action-bar"):
                yield Button("Review & Build →", id="btn-review", variant="primary")
                yield Button("Select All", id="btn-all", variant="default")
                yield Button("Clear", id="btn-none", variant="default")
        yield Footer()

    def _selected_features(self) -> List[Feature]:
        rows = self.query(FeatureRow)
        return [row.feature for row in rows if row.is_checked]

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-review":
            self.action_review()
        elif event.button.id == "btn-all":
            self.action_select_all()
        elif event.button.id == "btn-none":
            self.action_select_none()

    def action_select_all(self) -> None:
        for chk in self.query(Checkbox):
            chk.value = True

    def action_select_none(self) -> None:
        for chk in self.query(Checkbox):
            chk.value = False

    def action_review(self) -> None:
        selected = self._selected_features()
        if not selected:
            self.notify("Select at least one feature.", severity="warning")
            return
        self.app.push_screen(SummaryScreen(self.board, selected))


# ─────────────────────────────────────────────────────────────────────────────
# App
# ─────────────────────────────────────────────────────────────────────────────

CSS = """
Screen {
    background: $surface;
}

BoardPanel {
    height: 3;
    padding: 0 2;
    background: $panel;
    border-bottom: solid $primary;
    color: $text;
}

.section-label {
    padding: 1 2 0 2;
}

#feature-list {
    height: 1fr;
    padding: 0 2;
}

.feature-row {
    height: 3;
    align: left middle;
}

.feature-row Checkbox {
    width: 30;
}

.feature-desc {
    color: $text-muted;
    padding: 0 2;
}

#action-bar {
    height: 5;
    padding: 1 2;
    align: left middle;
    background: $panel;
    border-top: solid $primary;
}

#action-bar Button {
    margin-right: 2;
}

#build-log {
    height: 1fr;
    padding: 1 2;
}
"""


class JetsonKconfigApp(App):
    CSS = CSS
    TITLE = "jetson-kconfig"
    SUB_TITLE = "Jetson Kernel Module Configurator"

    def on_mount(self) -> None:
        board = detect_board()
        self.push_screen(MainScreen(board))


def main() -> None:
    app = JetsonKconfigApp()
    app.run()


if __name__ == "__main__":
    main()
