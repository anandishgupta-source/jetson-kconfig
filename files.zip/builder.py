"""Kernel build orchestration."""
from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
from pathlib import Path
from typing import AsyncIterator, List

from .detect import JetsonBoard
from .features import Feature


KERNEL_SRC_DEFAULT = Path("/usr/src/linux-headers-$(uname -r)")


async def build_modules(
    board: JetsonBoard,
    features: List[Feature],
) -> AsyncIterator[str]:
    """
    Generator that yields log lines while building selected kernel modules.

    Steps:
    1. Locate kernel source / headers
    2. Patch .config with selected CONFIG_ entries
    3. Run make modules_prepare
    4. Build individual modules
    5. Install modules
    6. Install userspace packages
    7. Run depmod
    """

    yield "── Step 1: Locating kernel source ──────────────────────"
    src = await _find_kernel_src()
    if src is None:
        yield "[red]✗ Kernel headers not found.[/]"
        yield "  Install with:"
        yield "  [cyan]sudo apt install linux-headers-$(uname -r)[/]"
        return
    yield f"  Found: {src}"

    yield ""
    yield "── Step 2: Patching kernel config ──────────────────────"
    config_path = src / ".config"
    if not config_path.exists():
        config_path = Path("/boot") / f"config-{_uname_r()}"

    if not config_path.exists():
        yield f"[red]✗ No .config found at {config_path}[/]"
        return

    # Backup original config
    backup = config_path.with_suffix(".config.bak")
    shutil.copy2(config_path, backup)
    yield f"  Backed up config → {backup}"

    all_configs: List[str] = []
    for feature in features:
        all_configs.extend(feature.configs)

    patched = _patch_config(config_path, all_configs)
    yield f"  Applied {patched} config entries"

    yield ""
    yield "── Step 3: Preparing build ──────────────────────────────"
    async for line in _run_cmd(["make", "-C", str(src), "modules_prepare"], cwd=str(src)):
        yield f"  {line}"

    yield ""
    yield "── Step 4: Building modules ─────────────────────────────"
    for feature in features:
        if not feature.modules:
            continue
        yield f"  Building {feature.name}..."
        for mod in feature.modules:
            mod_path = f"drivers/**/{mod}.ko"
            async for line in _run_cmd(
                ["make", "-C", str(src), "M=.", f"CONFIG_{mod.upper()}=m"],
                cwd=str(src),
            ):
                yield f"    {line}"

    yield ""
    yield "── Step 5: Installing modules ───────────────────────────"
    async for line in _run_cmd(
        ["make", "-C", str(src), "modules_install"],
        cwd=str(src),
        sudo=True,
    ):
        yield f"  {line}"

    yield ""
    yield "── Step 6: Installing userspace tools ───────────────────"
    packages: List[str] = []
    for feature in features:
        packages.extend(feature.packages)
    packages = list(dict.fromkeys(packages))  # deduplicate, preserve order

    if packages:
        yield f"  apt install {' '.join(packages)}"
        async for line in _run_cmd(
            ["apt-get", "install", "-y"] + packages,
            sudo=True,
        ):
            yield f"  {line}"
    else:
        yield "  (no userspace packages required)"

    yield ""
    yield "── Step 7: Running depmod ───────────────────────────────"
    async for line in _run_cmd(["depmod", "-a"], sudo=True):
        yield f"  {line}"

    yield ""
    yield "[bold green]✔  Build complete![/]"
    yield ""
    yield "Load modules now with:"
    for feature in features:
        for mod in feature.modules:
            yield f"  [cyan]sudo modprobe {mod}[/]"
    yield ""
    yield "To auto-load on boot, add module names to [cyan]/etc/modules[/]"


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _uname_r() -> str:
    try:
        return subprocess.check_output(["uname", "-r"], text=True).strip()
    except Exception:
        return ""


async def _find_kernel_src() -> Path | None:
    uname = _uname_r()
    candidates = [
        Path(f"/usr/src/linux-headers-{uname}"),
        Path(f"/usr/src/linux-{uname}"),
        Path("/usr/src/kernel"),
        Path("/lib/modules") / uname / "build",
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def _patch_config(config_path: Path, entries: List[str]) -> int:
    """
    Patch a kernel .config file with new CONFIG_ entries.
    Returns number of entries written.
    """
    text = config_path.read_text()
    lines = text.splitlines()
    count = 0

    for entry in entries:
        key, _, value = entry.partition("=")
        key = key.strip()
        value = value.strip()

        new_lines = []
        found = False
        for line in lines:
            if line.startswith(f"{key}=") or line.startswith(f"# {key} is not set"):
                new_lines.append(f"{key}={value}")
                found = True
            else:
                new_lines.append(line)
        lines = new_lines

        if not found:
            lines.append(f"{key}={value}")

        count += 1

    config_path.write_text("\n".join(lines) + "\n")
    return count


async def _run_cmd(
    cmd: List[str],
    cwd: str | None = None,
    sudo: bool = False,
) -> AsyncIterator[str]:
    if sudo and os.geteuid() != 0:
        cmd = ["sudo"] + cmd

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        cwd=cwd,
    )

    assert proc.stdout is not None
    async for raw in proc.stdout:
        yield raw.decode(errors="replace").rstrip()

    await proc.wait()
