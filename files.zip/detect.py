"""Auto-detect Jetson board model and L4T version."""
import os
import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class JetsonBoard:
    model: str
    soc: str
    l4t_version: str
    kernel_branch: str
    defconfig: str


BOARD_PROFILES = {
    # model substring → profile
    "orin nx":      ("tegra234", "35.x", "tegra_defconfig"),
    "orin nano":    ("tegra234", "35.x", "tegra_defconfig"),
    "agx orin":     ("tegra234", "35.x", "tegra_defconfig"),
    "xavier nx":    ("tegra194", "35.x", "tegra_defconfig"),
    "agx xavier":   ("tegra194", "35.x", "tegra_defconfig"),
    "nano":         ("tegra210", "32.x", "tegra_defconfig"),
    "tx2":          ("tegra186", "35.x", "tegra_defconfig"),
    "tx1":          ("tegra210", "32.x", "tegra_defconfig"),
}


def detect_board() -> Optional[JetsonBoard]:
    model = _read_device_tree_model() or _read_proc_model()
    if not model:
        return None

    model_lower = model.lower()
    for key, (soc, l4t, defconfig) in BOARD_PROFILES.items():
        if key in model_lower:
            l4t_ver = _read_l4t_version() or l4t
            branch = f"l4t-r{l4t_ver.split('.')[0]}"
            return JetsonBoard(
                model=model.strip(),
                soc=soc,
                l4t_version=l4t_ver,
                kernel_branch=branch,
                defconfig=defconfig,
            )

    # Unknown Jetson — return partial info
    return JetsonBoard(
        model=model.strip(),
        soc="unknown",
        l4t_version=_read_l4t_version() or "unknown",
        kernel_branch="unknown",
        defconfig="tegra_defconfig",
    )


def _read_device_tree_model() -> Optional[str]:
    path = "/proc/device-tree/model"
    try:
        with open(path, "r") as f:
            return f.read().rstrip("\x00")
    except (FileNotFoundError, PermissionError):
        return None


def _read_proc_model() -> Optional[str]:
    try:
        with open("/proc/cpuinfo", "r") as f:
            for line in f:
                if line.startswith("Hardware"):
                    return line.split(":", 1)[1].strip()
    except (FileNotFoundError, PermissionError):
        return None
    return None


def _read_l4t_version() -> Optional[str]:
    paths = [
        "/etc/nv_tegra_release",
        "/etc/nv_tegra_release.txt",
    ]
    for path in paths:
        try:
            with open(path, "r") as f:
                content = f.read()
                match = re.search(r"R(\d+).*REVISION: ([\d.]+)", content)
                if match:
                    return f"{match.group(1)}.{match.group(2)}"
        except (FileNotFoundError, PermissionError):
            continue
    return None
