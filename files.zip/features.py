"""Kernel feature definitions."""
from dataclasses import dataclass, field
from typing import List


@dataclass
class Feature:
    id: str
    name: str
    description: str
    configs: List[str]                  # CONFIG_ keys to enable
    modules: List[str] = field(default_factory=list)   # expected .ko names
    packages: List[str] = field(default_factory=list)  # apt packages for userspace tools
    notes: str = ""


FEATURES: List[Feature] = [
    Feature(
        id="can",
        name="CAN Bus",
        description="SocketCAN support — CAN_RAW, CAN_BCM, MCP251x SPI-CAN",
        configs=[
            "CONFIG_CAN=m",
            "CONFIG_CAN_RAW=m",
            "CONFIG_CAN_BCM=m",
            "CONFIG_CAN_GW=m",
            "CONFIG_CAN_DEV=m",
            "CONFIG_CAN_MCP251X=m",
            "CONFIG_CAN_MCP251XFD=m",
        ],
        modules=["can", "can_raw", "can_bcm", "can_dev", "mcp251x"],
        packages=["can-utils"],
        notes="Use 'ip link set can0 up type can bitrate 500000' to bring up interface",
    ),
    Feature(
        id="spi",
        name="SPI Devices",
        description="SPI bus and common SPI device drivers",
        configs=[
            "CONFIG_SPI=y",
            "CONFIG_SPI_SPIDEV=m",
            "CONFIG_SPI_TEGRA114=y",
        ],
        modules=["spidev"],
        packages=[],
        notes="Access via /dev/spidev*",
    ),
    Feature(
        id="i2c",
        name="I2C Devices",
        description="I2C bus and i2c-dev userspace access",
        configs=[
            "CONFIG_I2C=y",
            "CONFIG_I2C_CHARDEV=m",
            "CONFIG_I2C_MUX=m",
        ],
        modules=["i2c_dev"],
        packages=["i2c-tools"],
        notes="Access via /dev/i2c-*. Use i2cdetect to scan.",
    ),
    Feature(
        id="usb_gadget",
        name="USB Gadget",
        description="USB gadget mode — serial, ethernet, mass storage",
        configs=[
            "CONFIG_USB_GADGET=m",
            "CONFIG_USB_G_SERIAL=m",
            "CONFIG_USB_ETH=m",
            "CONFIG_USB_MASS_STORAGE=m",
            "CONFIG_USB_CONFIGFS=m",
        ],
        modules=["usb_f_serial", "usb_f_ecm", "g_serial"],
        packages=[],
        notes="Enables Jetson to act as USB device (serial/ethernet/storage)",
    ),
    Feature(
        id="gpio",
        name="GPIO / libgpiod",
        description="GPIO character device and sysfs access",
        configs=[
            "CONFIG_GPIO_SYSFS=y",
            "CONFIG_GPIO_CDEV=y",
        ],
        modules=[],
        packages=["gpiod", "libgpiod-dev"],
        notes="Use gpiodetect / gpioget / gpioset for userspace GPIO control",
    ),
    Feature(
        id="pwm",
        name="PWM",
        description="PWM sysfs and tegra PWM driver",
        configs=[
            "CONFIG_PWM=y",
            "CONFIG_PWM_SYSFS=y",
            "CONFIG_PWM_TEGRA=y",
        ],
        modules=[],
        packages=[],
        notes="Access via /sys/class/pwm/",
    ),
    Feature(
        id="v4l2",
        name="V4L2 / Camera",
        description="Video4Linux2 — cameras, capture cards, media devices",
        configs=[
            "CONFIG_VIDEO_DEV=m",
            "CONFIG_VIDEO_V4L2=m",
            "CONFIG_MEDIA_SUPPORT=m",
            "CONFIG_MEDIA_CAMERA_SUPPORT=y",
        ],
        modules=["videodev", "v4l2_common"],
        packages=["v4l-utils"],
        notes="Access via /dev/video*",
    ),
    Feature(
        id="uvc",
        name="USB Webcam (UVC)",
        description="USB Video Class driver for USB webcams",
        configs=[
            "CONFIG_USB_VIDEO_CLASS=m",
        ],
        modules=["uvcvideo"],
        packages=["v4l-utils"],
        notes="Plug-and-play support for most USB webcams",
    ),
    Feature(
        id="w1",
        name="1-Wire Bus",
        description="Dallas/Maxim 1-Wire protocol — DS18B20 temperature sensors etc.",
        configs=[
            "CONFIG_W1=m",
            "CONFIG_W1_MASTER_GPIO=m",
            "CONFIG_W1_SLAVE_THERM=m",
        ],
        modules=["wire", "w1_gpio", "w1_therm"],
        packages=[],
        notes="Use w1_gpio with GPIO pin via device tree overlay",
    ),
    Feature(
        id="ftdi",
        name="FTDI / USB-Serial",
        description="FTDI and other USB-to-serial adapters",
        configs=[
            "CONFIG_USB_SERIAL=m",
            "CONFIG_USB_SERIAL_FTDI_SIO=m",
            "CONFIG_USB_SERIAL_CP210X=m",
            "CONFIG_USB_SERIAL_CH341=m",
        ],
        modules=["ftdi_sio", "cp210x", "ch341"],
        packages=["picocom", "minicom"],
        notes="Shows up as /dev/ttyUSB*",
    ),
    Feature(
        id="wireguard",
        name="WireGuard VPN",
        description="WireGuard kernel module",
        configs=[
            "CONFIG_WIREGUARD=m",
        ],
        modules=["wireguard"],
        packages=["wireguard-tools"],
        notes="Fast modern VPN, built into kernel 5.6+",
    ),
    Feature(
        id="netfilter",
        name="Netfilter / iptables / nftables",
        description="Firewall and NAT support",
        configs=[
            "CONFIG_NETFILTER=y",
            "CONFIG_NF_TABLES=m",
            "CONFIG_NF_NAT=m",
            "CONFIG_IP_NF_IPTABLES=m",
            "CONFIG_IP_NF_FILTER=m",
        ],
        modules=["nf_tables", "nf_nat", "iptable_filter"],
        packages=["iptables", "nftables"],
        notes="Required for routing, NAT, and firewall rules",
    ),
]
